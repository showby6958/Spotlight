package com.capstone.spotlight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
